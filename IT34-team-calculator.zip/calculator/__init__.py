# __init__.py
from .operations import add, sub, mul, div  # noqa: F401
